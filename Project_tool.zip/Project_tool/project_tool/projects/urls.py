from django.urls import path
from .views import home
from . import views

urlpatterns = [
     path('', views.home, name='home'),
    path('features/', views.features, name='features'),
    path('contact/', views.contact, name='contact'),
]