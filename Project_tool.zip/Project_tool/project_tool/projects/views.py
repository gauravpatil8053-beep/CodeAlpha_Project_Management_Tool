from django.http import HttpResponse

def home(request):
    return HttpResponse("Hello Django! Backend is working 🚀")
from django.shortcuts import render

def home(request):
    return render(request, 'projects/index.html')
def features(request):
    return render(request, 'projects/features.html')

def contact(request):
    return render(request, 'projects/contact.html')
from django.shortcuts import render
from django.contrib import messages

def contact(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        message = request.POST.get('message')

       
        messages.success(request, "Message sent successfully!")

    return render(request, 'projects/contact.html')